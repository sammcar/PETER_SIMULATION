#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from std_msgs.msg import Float64

class JointPublisher(Node):
    def __init__(self):
        super().__init__('joint_publisher')
        self.publisher_ = self.create_publisher(Float64, '/joint_controller/position', 10)
        self.timer = self.create_timer(1.0, self.publish_joint_position)  # Publicar cada segundo

    def publish_joint_position(self):
        msg = Float64()
        msg.data = 1.0  # Cambia este valor según sea necesario
        self.publisher_.publish(msg)
        self.get_logger().info(f'Publishing: {msg.data}')

def main(args=None):
    rclpy.init(args=args)
    node = JointPublisher()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()


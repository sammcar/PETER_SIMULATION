import os
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, IncludeLaunchDescription
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration, PathJoinSubstitution, Command
from launch_ros.actions import Node
from ament_index_python.packages import get_package_share_directory

def generate_launch_description():

    pkg_urdf_path = get_package_share_directory('peter_robot')
    pkg_gazebo_path = get_package_share_directory('peter_robot')

    gazebo_models_path, ignore_last_dir = os.path.split(pkg_urdf_path)


        # Define el argumento 'world' correctamente
    world_arg = DeclareLaunchArgument(
        'world', 
        default_value=os.path.join(pkg_gazebo_path, 'worlds', 'empty.sdf'),
        description='Path to the Gazebo world file'
    )

    model_arg = DeclareLaunchArgument(
        'package', default_value='peter_old.urdf.xacro',
        description='Name of the URDF description to load'
    )

        # Define the path to your URDF or Xacro file
    urdf_file_path = PathJoinSubstitution([
        pkg_urdf_path,  # Replace with your package name
        "urdf",
        LaunchConfiguration('package')  # Replace with your URDF or Xacro file
    ])


    world_launch = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(pkg_gazebo_path, 'launch', 'world.launch.py'),
        ),
        launch_arguments={
        'world': LaunchConfiguration('world'),
        }.items()
    )

    # Spawn the URDF model using the `/world/<world_name>/create` service
    spawn_urdf_node = Node(
        package="ros_gz_sim",
        executable="create",
        arguments=[
            "-name", "my_robot",
            "-topic", "robot_description",
            "-x", "0.0", "-y", "0.0", "-z", "0.8", "-Y", "0.0"  # Initial spawn position
        ],
        output="screen",
        parameters=[
            {'use_sim_time': True},
        ]
    )


    robot_state_publisher_node = Node(
            package='robot_state_publisher',
            executable='robot_state_publisher',
            name='robot_state_publisher',
            output='screen',
            parameters=[
                {'robot_description': Command(['xacro', ' ', urdf_file_path]),
                'use_sim_time': True},
            ],
            remappings=[
                ('/tf', 'tf'),
                ('/tf_static', 'tf_static')
            ]
        )

        # Node to bridge messages like /cmd_vel and /odom
    gz_bridge_node = Node(
        package="ros_gz_bridge",
        executable="parameter_bridge",
        arguments=[
            "/cmd_vel@geometry_msgs/msg/Twist@gz.msgs.Twist",
            "/clock@rosgraph_msgs/msg/Clock@gz.msgs.Clock",
            "/joint_states@sensor_msgs/msg/JointState@gz.msgs.Model",
            "/tf@tf2_msgs/msg/TFMessage@gz.msgs.Pose_V",
            "/joint_controller/position@std_msgs/msg/Float64@gz.msgs.Double"

        ],
        output="screen",
        parameters=[
            {'use_sim_time': True},
        ]
    )


    launchDescriptionObject = LaunchDescription()
    launchDescriptionObject.add_action(model_arg)
    launchDescriptionObject.add_action(world_arg)  # Se debe agregar el argumento 'world'
    launchDescriptionObject.add_action(world_launch)
    launchDescriptionObject.add_action(spawn_urdf_node)
    launchDescriptionObject.add_action(robot_state_publisher_node)
    launchDescriptionObject.add_action(gz_bridge_node)

    return launchDescriptionObject
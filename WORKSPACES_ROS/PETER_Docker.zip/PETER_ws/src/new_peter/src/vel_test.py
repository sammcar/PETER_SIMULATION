#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist

class CmdVelPublisher(Node):
    def __init__(self):
        super().__init__('cmd_vel_publisher')
        self.publisher_ = self.create_publisher(Twist, '/cmd_vel', 10)

        # Temporizador para enviar comandos cada 0.1 segundos (10 Hz)
        self.timer = self.create_timer(0.1, self.publish_velocity)

        # Velocidades por defecto
        self.linear_speed = 0.2  # m/s
        self.angular_speed = 0.0  # rad/s

    def publish_velocity(self):
        msg = Twist()
        msg.linear.x = self.linear_speed
        msg.angular.z = self.angular_speed
        self.publisher_.publish(msg)
        self.get_logger().info(f'Enviando velocidad: linear={msg.linear.x}, angular={msg.angular.z}')

def main(args=None):
    rclpy.init(args=args)
    node = CmdVelPublisher()

    try:
        rclpy.spin(node)  # Mantiene el nodo ejecutándose
    except KeyboardInterrupt:
        node.get_logger().info("Nodo detenido")
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()


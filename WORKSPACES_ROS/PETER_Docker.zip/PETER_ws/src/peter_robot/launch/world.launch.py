import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, IncludeLaunchDescription
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import  LaunchConfiguration, PathJoinSubstitution, TextSubstitution


def generate_launch_description():

    world_arg = DeclareLaunchArgument(
        'world', default_value='empty.sdf',
        description='Name of the Gazebo world file to load'
    )

    pkg_mec_mobile = get_package_share_directory('peter_robot')
    pkg_ros_gz_sim = get_package_share_directory('ros_gz_sim')

    # Rutas que quieres agregar
    gazebo_models_path1 = "/home/Docker_folder/PETER_ws/src/peter_robot/meshes"
    gazebo_models_path2 = "/home/Docker_folder/PETER_ws/src/new_peter/meshes"

    # Obtener el valor actual de GZ_SIM_RESOURCE_PATH (si existe)
    current_paths = os.environ.get("GZ_SIM_RESOURCE_PATH", "")

    # Concatenar nuevas rutas sin sobrescribir las existentes
    new_paths = gazebo_models_path1 + os.pathsep + gazebo_models_path2

    # Si ya hay rutas, las agregamos al final
    if current_paths:
        new_paths = current_paths + os.pathsep + new_paths

    # Actualizar la variable de entorno
    os.environ["GZ_SIM_RESOURCE_PATH"] = new_paths



    gazebo_launch = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(pkg_ros_gz_sim, 'launch', 'gz_sim.launch.py'),
        ),
        launch_arguments={'gz_args': [PathJoinSubstitution([
            pkg_mec_mobile,
            'world',
            LaunchConfiguration('world')
        ]),
        #TextSubstitution(text=' -r -v -v1 --render-engine ogre')],
        TextSubstitution(text=' -r -v -v1')],
        'on_exit_shutdown': 'true'}.items()
    )

    launchDescriptionObject = LaunchDescription()

    launchDescriptionObject.add_action(world_arg)
    launchDescriptionObject.add_action(gazebo_launch)

    return launchDescriptionObject

Para ejecutar el terreno:
$cd map/
$gazebo my_terrain.sdf

Objetivo actual
Meter esto en un workspace de ROS2 y ejecutarlo junto a un robot
